import os
from graphic_enhancer import graphic_enhancer_tweaks
from network_latency import network_latency_tweaks
from ram_cpu import ram_cpu_tweaks

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def run_tweaks(tweaks, category_name):
    print(f"\n--- Running {category_name} Tweaks ---")
    for func in tweaks:
        func()
    print(f"{category_name} tweaks complete!\n")
    input("Press Enter to return to menu...")

def main_menu():
    while True:
        clear_screen()
        print("========= Omnic Summer =========")
        print("1. Graphic Enhancer (30 tweaks)")
        print("2. Network & Latency Reduction (30 tweaks)")
        print("3. RAM & CPU Optimization (30 tweaks)")
        print("4. Run ALL Tweaks (Full Bundle)")
        print("0. Exit")
        choice = input("Select an option: ").strip()
        if choice == "1":
            run_tweaks(graphic_enhancer_tweaks, "Graphic Enhancer")
        elif choice == "2":
            run_tweaks(network_latency_tweaks, "Network & Latency Reduction")
        elif choice == "3":
            run_tweaks(ram_cpu_tweaks, "RAM & CPU Optimization")
        elif choice == "4":
            run_tweaks(graphic_enhancer_tweaks, "Graphic Enhancer")
            run_tweaks(network_latency_tweaks, "Network & Latency Reduction")
            run_tweaks(ram_cpu_tweaks, "RAM & CPU Optimization")
        elif choice == "0":
            print("Goodbye!")
            break
        else:
            print("Invalid option. Try again.")
            input("Press Enter to continue...")

if __name__ == "__main__":
    main_menu()