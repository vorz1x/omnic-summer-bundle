def tweak1():
    print("[RAM & CPU] Tweak 1 executed.")

# ... up to tweak30

def tweak30():
    print("[RAM & CPU] Tweak 30 executed.")

ram_cpu_tweaks = [
    tweak1, # ... add all tweak functions up to tweak30
    tweak30
]